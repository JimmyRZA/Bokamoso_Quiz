package com.bokamoso;

/**
 * @author Jimmy Mhlanga
 *
 */
public interface TextFormatInt {
	
	public String formatText(String text, int length);

}
