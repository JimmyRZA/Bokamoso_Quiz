package com.bokamoso;

import org.apache.commons.lang.StringUtils;

/**
 * @author Jimmy Mhlanga
 *
 */
public class TextFormatter implements TextFormatInt {
	
	TextFormatter() {
		
	}

	public String formatText(String text, int length) {
		StringBuilder formatedText = new StringBuilder();
		String newText= "";
		
		while (text.length() > 0) {
			if(text.length() > length)
				newText = text.substring(0, length);
			else 
				newText = text.substring(0, text.length());
			
			formatedText.append((StringUtils.leftPad(newText, length, " ")));
			formatedText.append("\n");
			if(text.length() > length)
				text = text.substring(length, text.length());
			else
				text = text.substring(text.length());
		}
		return formatedText.toString();		
	}
	

}
