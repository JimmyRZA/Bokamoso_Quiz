package com.bokamoso;

/**
 * @author Jimmy Mhlanga
 *
 */
public class BokamosoQuiz {
	public static void main(String[] args) {
		String text = "Although the development of mathematical logic did not follow Boole's program, the connection between his algebra and logic was later put on firm ground in the setting of algebraic logic, which also studies the algebraic systems of many other logics.";
		
		TextFormatter formatter = new TextFormatter();
		
		System.out.println(formatter.formatText(text, 40));
		
	}
}
